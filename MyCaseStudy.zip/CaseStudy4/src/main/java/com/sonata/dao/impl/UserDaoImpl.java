package com.sonata.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysql.jdbc.PreparedStatement;
import com.sonata.dao.Task;
import com.sonata.dao.User;
import com.sonata.dao.UserInterface;

@Component
public class UserDaoImpl implements UserInterface{
	@Autowired
	DbConnection db;
	int row = 0;
	@Autowired
	User user = null;
	boolean c;
	
	@Override
	public int createUser(User user) {
		try {
			PreparedStatement ps = (PreparedStatement) db.getConnection().prepareStatement("Insert into User values (?,?,?,?,?,?,?,?,?,?,?)");
			ps.setInt(1, user.getUser_Id());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getUsername());
			ps.setString(4, user.getEmail());
			ps.setString(5, user.getFirst_Name());
			ps.setString(6, user.getLast_Name());
			ps.setLong(7, user.getContact_Number());
			ps.setString(8, user.getRole());
			ps.setBoolean(9, user.getIsactive());
			ps.setString(10, user.getDob());
			ps.setString(11, user.getCreated_on());
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException sqe) {sqe.printStackTrace();}
		
		return row;
	}
	
	public boolean validateUser(String Username, String Password){
		try {
		PreparedStatement ps = (PreparedStatement) db.getConnection().prepareStatement("select Username, Password from User where Username =?");
		ps.setString(1, Username);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			if(Username.equals(rs.getString(1)) && Password.equals(rs.getString(2))) {
				c = true;
			}
			else {
				c = false;
			}
		}
		}catch(SQLException sqe) {sqe.printStackTrace();}
		
		return c;
	}
	
	public  List<User> getAllUsers(){
		List<User> userList = new ArrayList<>();
		try {
			PreparedStatement ps1 = (PreparedStatement) db.getConnection().prepareStatement
					("select * from User");
			ResultSet rs = ps1.executeQuery();
			while(rs.next()) {
				User t = new User();
				int User_Id = rs.getInt(1);
				String Password = rs.getString(2);
				String Username = rs.getString(3);
				String Email = rs.getString(4);
				String First_Name = rs.getString(5);
				String Last_Name = rs.getString(6);
				long Contact_Number = rs.getLong(7);
				String Role = rs.getString(8);
				Boolean Isactive = rs.getBoolean(9);
				String Dob = rs.getString(10);
				String Created_on = rs.getString(11);
				
				t.setUser_Id(User_Id);
				t.setPassword(Password);
				t.setUsername(Username);
				t.setEmail(Email);
				t.setFirst_Name(First_Name);
				t.setLast_Name(Last_Name);
				t.setContact_Number(Contact_Number);
				t.setRole(Role);
				t.setIsactive(Isactive);
				t.setDob(Dob);
				t.setCreated_on(Created_on);
				userList.add(t);
				
			}	
		}catch(SQLException se) { se.printStackTrace();}
		return userList;
		
	}
	
	

}
