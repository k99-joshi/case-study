export interface Interface{
    owner_ID : number;
    task_ID :number;
    
    
    
}