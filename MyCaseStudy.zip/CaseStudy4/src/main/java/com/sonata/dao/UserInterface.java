package com.sonata.dao;

import java.util.List;

public interface UserInterface {
	public int createUser(User user);
	public boolean validateUser(String Username, String Password);
	public  List<User> getAllUsers();

}
